# femboy downloader

an image downloader for the [nyarch linux](github.com/NyarchLinux/NyarchLinux) distro based on my own [wallpaper downloader](github.com/princess-wawa/wallpaper-downloader) (but with reddit instead of regular apis)

## to install just run

```bash
cd /tmp
wget https://github.com/princess-wawa/femboy-downloader/releases/latest/download/femboy-downloader.flatpak
flatpak install femboy-downloader.flatpak
```
